import pandas as pd
import matplotlib.pyplot as plt

data = pd.read_csv('trajectory.csv')

plt.plot(data['x'], data['y'])
plt.xlabel('X')
plt.ylabel('Y')
plt.title('Robot Trajectory')
plt.axis('equal')
plt.grid()
plt.ticklabel_format(style='plain') 
plt.scatter(data['x'][0], data['y'][0], label='Start')
plt.scatter(data['x'].iloc[-1], data['y'].iloc[-1], label='End')
plt.savefig("trajectory.png")
plt.legend()
plt.show()
