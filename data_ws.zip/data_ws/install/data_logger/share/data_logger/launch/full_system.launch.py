from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import ExecuteProcess

def generate_launch_description():

    return LaunchDescription([

        #  Start TurtleBot3 Gazebo
        ExecuteProcess(
            cmd=['ros2', 'launch', 'turtlebot3_gazebo', 'turtlebot3_world.launch.py'],
            output='screen'
        ),

        #  Start Logger Node
        Node(
            package='data_logger',
            executable='logger',
            name='odom_logger',
            output='screen'
        ),

        #  Teleop Keyboard
        ExecuteProcess(
            cmd=['gnome-terminal', '--',
        'bash', '-c',
        'source ~/data_ws/install/setup.bash && ros2 run teleop_twist_keyboard teleop_twist_keyboard; exec bash'],
            output='screen',
          
        ),
    ])
