from setuptools import find_packages, setup
import os
from glob import glob

package_name = 'data_logger'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),

        # Launch files included
        (os.path.join('share', package_name, 'launch'),
            glob('launch/*.launch.py')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='kavin',
    maintainer_email='kaving018@gmail.com',
    description='ROS2 trajectory logger with plotting',
    license='MIT',
    entry_points={
        'console_scripts': [
           'logger = data_logger.logger_node:main',
        ],
    },
)
