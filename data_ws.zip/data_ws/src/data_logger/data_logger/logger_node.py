import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
import csv

class OdomLogger(Node):
    def __init__(self):
        super().__init__('odom_logger')

        self.subscription = self.create_subscription(
            Odometry,
            '/odom',
            self.listener_callback,
            10
        )

        self.file = open('trajectory.csv', 'w', newline='')
        self.writer = csv.writer(self.file)
        self.writer.writerow(['x', 'y'])

    def listener_callback(self, msg):
        x = msg.pose.pose.position.x
        y = msg.pose.pose.position.y

        self.writer.writerow([x, y])
        self.get_logger().info(f'{x:.2f}, {y:.2f}')

def main(args=None):
    rclpy.init(args=args)
    node = OdomLogger()
    rclpy.spin(node)

    node.file.close()
    node.destroy_node()
    rclpy.shutdown()
